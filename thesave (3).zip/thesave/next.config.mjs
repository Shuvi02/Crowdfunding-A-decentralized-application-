/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: ['api.pinata.cloud', 'tse4.mm.bing.net', 'gateway.pinata.cloud'],
  },
};

export default nextConfig;
